<?php include_once("inc_header.php")?>
<?php include_once("inc/inc_fungsi.php")?>
        <!-- untuk home -->
        <section id="home">
            <img src="<?php echo ambil_gambar('9')?>"/>
            <div class="kolom">
                <p class="deskripsi"><?php echo ambil_kutipan('9')?></p>
                <h3><?php echo ambil_judul('9')?></h3>
                <p><?php echo maximum_kata(ambil_isi('9'),30)?></p>
                <p><a href="<?php echo buat_link_halaman('9')?>" class="tbl-pink">Pelajari Lebih Lanjut</a></p>
            </div>
        </section>

        <!-- untuk personal-->
        <section id="personal">
            <div class="tengah">
                <div class="kolom">
                    <h2>Personal</h2>
                    <p class="deskripsi">About activity history student</p>
                    <p style="font-family: 'comic sans ms';">Disini kamu bisa melihat status peminjaman, pengembalian dan Pemesanan (booking) buku, jurnal atau skripsi.</p>
                    <p><a href="status-peminjaman.php" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
                </div>
            </div>
        </section>

        <!-- untuk news & event -->
        <section id="news&event">
            <div class="kolom">
                <p class="deskripsi"><?php echo ambil_kutipan('10')?></p>
                <h2><?php echo ambil_judul('10')?></h2>
                <p><?php echo maximum_kata(ambil_isi('10'),20)?></p>
                <p><a href="<?php echo buat_link_halaman('10')?>" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
            </div>
            <img src="<?php echo ambil_gambar('10')?>"/>
        </section>

        <!--untuk services-->
        <section id="services">
            <div class="tengah">
                <div class="kolom">
                    <h2>Services</h2>
                    <p class="deskripsi">Our Services</p>
                </div>

                <div class="services-list">
                    <?php
                    $sql1  = "select * from services order by id desc";
                    $q1    = mysqli_query($koneksi,$sql1);
                    while ($r1 = mysqli_fetch_array($q1)){
                        ?>
                            <div class="kartu-services">
                                <a href="<?php echo buat_link_services($r1['id'])?>">
                                    <img src="<?php echo url_dasar()."/gambar/".services_foto($r1['id'])?>" />
                                    <p><?php echo $r1['nama']?></p>
                                </a>
                            </div>
                            <?php
                        }
                    ?>
                </div>
            </div>
        </section>
<?php include_once("inc_footer.php")?>