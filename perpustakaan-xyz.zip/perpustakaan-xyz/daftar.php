<html>
    <head>
        <style type="text/css">
            body{
                background-image: url(https://img.freepik.com/premium-photo/blurred-bookshelf-library-room_1484-1953.jpg?size=626&ext=jpg&ga=GA1.2.1853630230.1666961951&semt=sph);
                background-repeat: no-repeat;
                background-size: 100%;
            }

            table {
                text-align : center;
                margin-left: 140px;
            }
        </style>
    </head>
</html>
<?php include("inc_header.php")?>
<?php
if(isset($_SESSION['users_email']) != ''){ //sudah dalam keadaan login
    header("location:index.php");
    exit();
}
?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h3>Pendaftaran</h3>
<?php
$email    = "";
$nama     = "";
$eror     = "";
$sukses    = "";

if(isset($_POST['simpan'])){
    $email                =$_POST['email'];
    $nama                 =$_POST['nama'];
    $password             =$_POST['password'];
    $konfirmasi_password  =$_POST['konfirmasi_password'];

    if($email == '' or $nama == '' or $konfirmasi_password == '' or $password == ''){
        $eror .= "<li>Silahkan masukkan semua isian.</li>";
    }

    //cek dibagian db, apakah email sudah ada atau belum
    if($email != ''){
        $sql1 = "select email from users where email = '$email'";
        $q1   = mysqli_query($koneksi,$sql1);
        $n1   = mysqli_num_rows($q1);
        if($n1 > 0){
            $eror .= "<li>Email yang kamu masukkan sudah terdaftar.</li>";
        }
        //validasi email
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            $eror .= "<li>Email yang kamu masukkan tidak valid.</li>";
        }
    }
    //cek kesesuaian password & konfirmasi password
    if($password != $konfirmasi_password){
        $eror .= "<li>Password dan Konfirmasi Password tidak sesuai.</li>";
    }
    if(strlen($password) < 6){
        $eror .= "<li>Panjang karakter yang diizinkan untuk password paling tidak 6 karakter.</li>";
    }
    if(empty($eror)){
        $status        = md5(rand(0,1000));
        $judul_email   = "Halaman Konfirmasi Pendaftaran";
        $isi_email     = "Akun yang kamu miliki dengan email <b>$email</b> telah siap digunakan.<br/>";
        $isi_email     .= "Sebelumnya silahkan melakukan aktivitas email dilink bawah ini:</br>";
        $isi_email     .= url_dasar()."/verifikasi.php?email=$email&kode=$status";

        kirim_email($email, $nama, $judul_email, $isi_email);

        $sql1 = "insert into users(email,nama,password,status) values('$email','$nama',md5($password),'$status')";
        $q1   = mysqli_query($koneksi,$sql1);
        if($q1){
            $sukses = "Proses Berhasil. Silahkan cek email kamu untuk verifikasi.";
        }
    }
}
?>
<?php if($eror) {echo "<div class='eror'><ul>$eror</ul></div>";} ?>
<?php if($sukses) {echo "<div class='sukses'><ul>$sukses</ul></div>";} ?>
<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Email</td>
            <td>
                <input type="text" name="email" class="input" value="<?php echo $email?>"/>
            </td>
        </tr>
        <tr>
            <td class="label">Nama</td>
            <td>
                <input type="text" name="nama" class="input" value="<?php echo $nama?>"/>
            </td>
        </tr>
        <tr>
            <td class="label">Password</td>
            <td>
                <input type="password" name="password" class="input"/>
            </td>
        </tr>
        <tr>
            <td class="label">Konfirmasi Password</td>
            <td>
                <input type="password" name="konfirmasi_password" class="input"/>
                <br/>
                Sudah punya akun? Silahkan <a href='<?php url_dasar()?>login.php'>login</a>
            </td>
        </tr>
    </table>
    <table>
        <tr>
            <td>
                <input style="margin-left: 190px;" type="submit" name="simpan" value="Simpan" class="tbl-biru"/>
            </td>
        </tr>
    </table>
    <br><br>
</form>
<?php include("inc_footer.php")?>