<?php
session_start();
unset($_SESSION['users_email']);
unset($_SESSION['users_nama']);
session_destroy();
header("location:index.php");
?>