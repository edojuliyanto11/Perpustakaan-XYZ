<?php include("inc_header.php")?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h3>Lupa Password</h3>
<?php
if(isset($_SESSION['users_email']) != ''){
    header("location:index.php");
    exit();
}

$err        = "";
$sukses     = "";
$email      = "";

if(isset($_POST['submit'])){
    $email  = $_POST['email'];
    if($email == ''){
        $err  = "Silahkan masukkan email";
    }else{
        $sql1 = "select * from users where email = '$email'";
        $q1   = mysqli_query($koneksi,$sql1);
        $n1   = mysqli_num_rows($q1);

        if($n1 < 1){
            $err = "Email: <b>$email</b> tidak ditemukan";
        }
    }

    if(empty($err)){
        $token_ganti_password   = md5(rand(0,1000));
        $judul_email            = "Ganti Password";
        $isi_email              = "Seseorang meminta untuk melakukan perubahan password. Silahkan klik link di bawah ini:<br/>";
        $isi_email             .= url_dasar()."/ganti_password.php?email=$email&token=$token_ganti_password";
        kirim_email($email, $email, $judul_email, $isi_email);

        $sql1   = "update users set token_ganti_password = '$token_ganti_password' where email = '$email'";
        mysqli_query($koneksi,$sql1);
        $sukses  = "Link ganti password sudah dikirimkan ke email anda.";
    }
}
?>
<?php if($err){ echo "<div class='eror'>$err</div>";}?>
<?php if($sukses){ echo "<div class='sukses'>$sukses</div>";}?>
<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Email</td>
            <td><input type="text" name="email" class="input" value="<?php echo $email?>"/></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Lupa Password" class="tbl-biru"/>
            </td>
        </tr>
    </table>
</form>
<?php include("inc_footer.php")?>