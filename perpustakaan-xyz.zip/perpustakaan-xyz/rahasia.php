<?php include("inc_header.php")?>
<?php
if($_SESSION['users_email'] == ''){ //dia belum login
    header("location:login.php");
    exit();
}
?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<div style="background-color: red;font-size: large;padding: 50px;color:#FFFFFF;">
Selamat Datang <?php echo $_SESSION['users_nama']?> di halaman rahasia. Hanya yang sudah login yang bisa akses halaman ini.
</div>
<?php include("inc_footer.php")?>