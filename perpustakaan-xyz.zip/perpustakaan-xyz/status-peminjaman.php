<?php include_once("inc_header_personal.php")?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal</title>
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<body>
    <div class="container">
        <h1>Status Peminjaman</h1>
        <table id="example" class="table table-striped">
        <thead>
            <tr>
                <th>NIB</th>
                <th>Judul</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Kembali</th>
                <th>Denda</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include "inc/inc_koneksi.php";
                $status_peminjaman = mysqli_query($koneksi,"select * from status_peminjaman");
                while($row = mysqli_fetch_array($status_peminjaman)){
                    echo "<tr>
                    <td>".$row['nib']."</td>
                    <td>".$row['judul']."</td>
                    <td>".$row['tanggal_pinjam']."</td>
                    <td>".$row['tanggal_kembali']."</td>
                    <td>".$row['denda']."</td>
                    <td>".$row['keterangan']."</td>";
                }
            ?>
        </tbody> 
        </table>
    </div>
    <script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
    </script>
</body>
</html>
<?php include_once("inc_footer.php")?>
