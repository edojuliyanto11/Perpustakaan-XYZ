<html>
    <head>
        <style type="text/css">
            body {
                background-image: url(https://img.freepik.com/free-photo/abstract-blur-beautiful-luxury-shopping-mall-center_1339-4083.jpg?size=626&ext=jpg&ga=GA1.2.1853630230.1666961951&semt=sph);
                background-repeat: no-repeat;
                background-size: 100%;
            }

            table {
                text-align : center;
                margin-left: 140px;
            }
        </style>
            <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
        <script>
            (function(h,o,t,j,a,r){
                h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
                h._hjSettings={hjid:3191278,hjsv:6};
                a=o.getElementsByTagName('head')[0];
                r=o.createElement('script');r.async=1;
                r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
                a.appendChild(r);
            })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
        </script>
    </head>
<?php include("inc_header.php")?>
<br>
<h3 style="text-align:center;">LOGIN</h3>
<?php
$email      = "";
$password   = "";
$err        = "";

if(isset($_POST['login'])){
    $email      = $_POST['email'];
    $password   = $_POST['password'];

    if($email == '' or $password == ''){
        $err .= "<li>Silahkan masukkan semua isian</li>";
    }else{
        $sql1 = "select * from users where email = '$email'";
        $q1   = mysqli_query($koneksi,$sql1);
        $r1   = mysqli_fetch_array($q1);
        $n1   = mysqli_num_rows($q1);

        if($r1['status'] != '1' &&  $n1 > 0){
            $err .= "<li>Akun yang kamu miliki belum aktif</li>";
        }

        if($r1['password'] != md5($password) && $n1 > 0 && $r1['status'] == '1'){
            $err .= "<li>Password tidak sesuai</li>";
        }

        if($n1 < 1){
            $err .= "<li>Akun tidak temukan</li>";
        }

        if(empty($err)){
            $_SESSION['users_email'] = $email;
            $_SESSION['users_nama'] = $r1['nama'];
            header("location:rahasia.php");
            exit();
        }
    }
}
?>
<?php if($err){echo "<div class='eror'><ul class='pesan'>$err</ul></div>";} ?>
<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Email</td>
            <td><input type="text" name="email" class="input" value="<?php echo $email?>"/></td>
        </tr>
        <tr>
            <td class="label">Password</td>
            <td><input type="password" name="password" class="input"/></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="login" value="Login" class="tbl-biru"/></td>
        </tr>
    </table>
</form>
<br><br><br><br><br><br><br>
<?php include("inc_footer.php")?>