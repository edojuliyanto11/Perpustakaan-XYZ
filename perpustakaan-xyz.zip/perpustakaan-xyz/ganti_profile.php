<?php include("inc_header.php")?>
<?php
if(isset($_SESSION['users_email']) == ''){ //belum sudah dalam keadaan login
    header("location:login.php");
    exit();
}
?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h3>Ganti Profile Akun</h3>
<?php
$email    = "";
$nama     = "";
$err      = "";
$sukses   = "";

if(isset($_POST['simpan'])){
    $nama                 = $_POST['nama'];
    $password_lama        = $_POST['password_lama'];
    $password             = $_POST['password'];
    $konfirmasi_password  = $_POST['konfirmasi_password'];

    if($nama == ''){
        $err .= "<li>Silahkan masukkan nama lengkap</li>";
    }

    if($password != ''){    //jika akan melakukan perubahan password
        $sql1 = "select * from users where email = '".$_SESSION['users_email']."'";
        $q1 = mysqli_query($koneksi,$sql1);
        $r1 = mysqli_fetch_array($q1);
        if(md5($password_lama) != $r1['password']){
            $err .= "<li>Password yang kamu tuliskan tidak sesuai dengan password sebelumnya</li>";
        }

        if($password_lama == '' or $konfirmasi_password == '' or $password == ''){
            $err .= "<li>Silahkan masukkan password lama, password baru serta konfirmasi password</li>";
        }

        if($password != $konfirmasi_password){
            $err .= "<li>Silahkan masukkan password dan konfirmasi password yang sama</li>";
        }

        if(strlen($password) < 6){
            $err .= "<li>Panjang karakter yang diizinkan untuk password adalah 6 karakter, minimal.</li>";
        }
    }

    if(empty($err)){
        $sql = "update users set nama = '".$nama."'where email = '".$_SESSION['users_email']."'";//perikasa users_email sama $sql
        mysqli_query($koneksi,$sql);
        $_SESSION['users_nama'] = $nama;

        if($password){
            $sql2 = "update users set password = md5($password) where email = '".$_SESSION['users_email']."'";
            mysqli_query($koneksi,$sql2);
        }

        $sukses = "Data berhasil diubah";
    }
}
?>
<?php if($err) {echo "<div class='err'><ul>$err</ul></div>";}?>
<?php if($sukses) {echo "<div class='sukses'><ul>$sukses</ul></div>";}?>

<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Email</td>
            <td>
                <?php echo $_SESSION['users_email']?>
            </td>
        </tr>
        <tr>
            <td class="label">Nama</td>
            <td>
                <input type="text" name="nama" class="input" value="<?php echo $_SESSION['users_nama']?>"/>
            </td>
        </tr>
        <tr>
            <td class="label">Password Lama</td>
            <td>
                <input type="password" name="password_lama" class="input"/>
            </td>
        </tr>
        <tr>
            <td class="label">Password Baru</td>
            <td>
                <input type="password" name="password" class="input"/>
            </td>
        </tr>
        <tr>
            <td class="label">Konfirmasi Password</td>
            <td>
                <input type="password" name="konfirmasi_password" class="input"/>
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="simpan" value="Simpan" class="tbl-biru"/>
            </td>
        </tr>
    </table>
</form>

<?php include("inc_footer.php")?>