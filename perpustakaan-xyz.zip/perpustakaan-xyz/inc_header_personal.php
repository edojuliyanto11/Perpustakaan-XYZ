<?php
include_once("inc/inc_koneksi.php");
include_once("inc/inc_fungsi.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal-Perpustakaan XYZ</title>
    <link rel="stylesheet" href="<?php echo url_dasar()?>/css/style.css">
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
            })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<body>
    <nav>
        <!╌ menampung menu dan logo ╌>
        <div class="wrapper">
            <div class="logo"><a href='<?php echo url_dasar()?>'>Perpustakaan XYZ</a></div>
                <div class="menu">
                    <ul>
                        <li><a href="status-peminjaman.php">Status Peminjaman</a></li>
                        <li><a href="status-pengembalian.php">Status Pengembalian</a></li>
                        <li><a href="status-pemesanan.php">Status Pemesanan</a></li>
                        <li><a href="informasi-journal.php">Informasi E-Journal</a></li>
                        <li><a href="daftar.php" class="tbl-biru">Sign Up</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="mb-3 row">
        <a href="index.php" class="tbl-biru" style="width: 100px;height:50px;text-align:center;margin-left:180px;margin-left:180px;">Kembali</a>
    </div>
    <div class="wrapper">
