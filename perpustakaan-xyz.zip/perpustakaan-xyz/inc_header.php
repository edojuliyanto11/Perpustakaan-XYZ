<?php
session_start();
include_once("inc/inc_koneksi.php");
include_once("inc/inc_fungsi.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home-Perpustakaan XYZ</title>
    <link rel="stylesheet" href="<?php echo url_dasar()?>/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:3191278,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<body>
    <nav style="background-color: #DEF5E5;">
        <!╌ menampung menu dan logo ╌>
        <div class="wrapper">
            <div class="logo"><a href='<?php echo url_dasar()?>'>Perpustakaan XYZ</a></div>
                <div class="menu">
                    <ul>
                        <li><a href="<?php echo url_dasar()?>#home">Home</a></li>
                        <li><a href="<?php echo url_dasar()?>#personal">Personal</a></li>
                        <li><a href="<?php echo url_dasar()?>#news&event">News & Event</a></li>
                        <li><a href="<?php echo url_dasar()?>#services">Services</a></li>
                        <li><a href="search-buku.php">Search</a></li>
                        <li><a href="<?php echo url_dasar()?>#contact">Contact Us</a></li>
                        <li>
                        <?php if(isset($_SESSION['users_nama'])){
                            echo "<a href='".url_dasar()."/ganti_profile.php'>".$_SESSION['users_nama']."</a> | <a href='".url_dasar()."/logout.php'>Logout</a>";
                        }else{?>
                            <a href="daftar.php" class="tbl-biru">Sign Up</a>
                        <?php } ?>
                        </li>
                        <li><a href="admin/login.php" class="tbl-biru" style="margin-left: 20px;">Admin Page</a></li>
                    </ul>
                </div>
        </div>
    </nav>
    <div class="wrapper">