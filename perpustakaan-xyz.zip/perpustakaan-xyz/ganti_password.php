<?php include("inc_header.php")?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h3>Ganti Password</h3>
<?php
if(isset($_SESSION['users_email']) != ''){
    header("location:index.php");
    exit();
}

$err        = "";
$sukses     = "";

$email      = $_GET['email'];
$token      = $_GET['token'];

if($token == '' or $email == ''){
    $err .= "Link tidak valid. Email dan token tidak tersedia.</br>";
}else{
    $sql1 = "select * from users where email = '$email' and token_ganti_password = '$token'";
    $q1   = mysqli_query($koneksi,$sql1);
    $n1   = mysqli_num_rows($q1);

    if($n1 < 1){
        $err  .= "Link tidak valid. Email dan token tidak sesuai";
    }
}

if(isset($_POST['submit'])){
    $password = $_POST['password'];
    $konfirmasi_password = $_POST['konfirmasi_password'];

    if($password == '' or $konfirmasi_password == ''){
        $err .= "Silahkan masukkan password serta konfirmasi password";
    }elseif($konfirmasi_password != $password){
        $err .= "Konfirmasi password tidak sesuai dengan password";
    }elseif(strlen($password)<6){
        $err .= "Jumlah karakter yang diperbolehkan untuk password minimal 6 karakter";
    }

    if(empty($err)){
        $sql1 = "update users set token_ganti_password = '',password=md5($password) where email = '$email'";
        mysqli_query($koneksi,$sql1);
        $sukses = "Password berhasil diganti.Silahkan <a href='".url_dasar()."/login.php'>login</a>.";
    }
}
?>
<?php if($err){ echo "<div class='eror'>$err</div>";}?>
<?php if($sukses){ echo "<div class='sukses'>$sukses</div>";}?>
<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Password</td>
            <td><input type="password" name="password" class="input"/></td>
        </tr>
        <tr>
            <td class="label">Konfirmasi Password</td>
            <td><input type="password" name="konfirmasi_password" class="input"/></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Ganti Password" class="tbl-biru"/>
            </td>
        </tr>
    </table>
</form>
<?php include("inc_footer.php")?>