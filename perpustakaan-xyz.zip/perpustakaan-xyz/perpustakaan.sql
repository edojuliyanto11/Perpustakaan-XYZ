-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2022 at 04:53 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'c33367701511b4f6020ec61ded352059');

-- --------------------------------------------------------

--
-- Table structure for table `halaman`
--

CREATE TABLE `halaman` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `kutipan` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `halaman`
--

INSERT INTO `halaman` (`id`, `judul`, `kutipan`, `isi`, `tgl_isi`) VALUES
(9, 'CHECK THIS OUT!', '', '<p style=\"text-align: left; line-height: 2;\"><img src=\"../gambar/fc221309746013ac554571fbd180e1c8.webp\" class=\"note-float-left\" style=\"font-family: var(--bs-font-sans-serif); font-size: 1rem; width: 626px; float: left;\"><span style=\"font-family: &quot;Comic Sans MS&quot;; font-size: 1rem;\">Halo readers,</span></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">Berikut adalah daftar buku baru yang baru publish di perpustakaan xyz:</span></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">- </span><b><span style=\"font-family: &quot;Comic Sans MS&quot;;\">KECERDASAN BUATAN DAN APLIKASINYA</span></b></p><p><img src=\"../gambar/a3c65c2974270fd093ee8a9bf8ae7d0b.jpg\" style=\"width: 233px;\"><br></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">- </span><b><span style=\"font-family: &quot;Comic Sans MS&quot;;\">APLIKASI SPSS dan SAS untuk Perancangan Percobaan</span></b></p><p><img src=\"../gambar/0f28b5d49b3020afeecd95b4009adf4c.png\" style=\"width: 199px;\"><br></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">- </span><b><span style=\"font-family: &quot;Comic Sans MS&quot;;\">MANAJEMEN PROYEK DENGAN SCRUM</span></b></p><p><img src=\"../gambar/bd686fd640be98efaae0091fa301e613.png\" style=\"width: 171px;\"><br></p><p></p>', '2022-11-17 12:45:57'),
(10, 'News & Event', '', '<p style=\"text-align: justify; margin-left: 25px;\">&nbsp;<img src=\"../gambar/0777d5c17d4066b82ab86dff8a46af6f.png\" style=\"width: 338px;\"></p><p style=\"text-align: justify; margin-left: 25px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\" ms\";=\"\" font-size:=\"\" 1rem;=\"\" text-align:=\"\" right;\"=\"\">Halo book lovers,&nbsp;</span><span style=\"font-size: 1rem; font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">Kamu Harus Tahu nih, Hari ini adalah hari buku sedunia yang jatuh pada setiap tanggal 23 April. Banyak orang merayakannya sebagai bentuk apresiasi terhadap buku yang menjadi pembuka wawasan. Kecintaan terhadap buku membuat&nbsp;</span><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\" ms\";=\"\" font-size:=\"\" 1rem;\"=\"\">kata-kata&nbsp;</span><span style=\"font-size: 1rem; font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">ucapan hari buku sedunia banyak dicari orang. Ungkapan serta pemahaman dari tokoh terkenal tentang buku termasuk hal yang dicari dalam kata-kata ucapan hari buku sedunia. Berikut kata-kata ucapan dari beberapa tokoh terkenal:</span></p><p style=\"text-align: justify; overflow-wrap: break-word; color: rgb(68, 68, 68); font-family: AcuminPro, arial, helvetica, sans-serif; font-size: 15px; margin-left: 25px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">1. \"Selamat hari buku sedunia, teman-teman! Jangan lupa ya, bukunya boleh dikoleksi dan difoto-foto, tapi juga harus dibaca. Hidup buku! hidup para pembaca!\" - Bernard Batubara</span></p><p style=\"text-align: justify; overflow-wrap: break-word; color: rgb(68, 68, 68); font-family: AcuminPro, arial, helvetica, sans-serif; font-size: 15px; margin-left: 25px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">2. \"Selamat Hari Buku Nasional. Perbanyak membaca buku, agar pertanyaan “bagaimana cara menulis” tidak perlu lagi ada\" - Fiersa Besari</span></p><p style=\"text-align: justify; overflow-wrap: break-word; color: rgb(68, 68, 68); font-family: AcuminPro, arial, helvetica, sans-serif; font-size: 15px; margin-left: 25px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">3. \"Cuma perlu satu buku untuk jatuh cinta pada membaca. Cari buku itu, mari jatuh cinta! Selamat Hari Buku\" - Najwa Shihab</span></p><p style=\"text-align: justify; overflow-wrap: break-word; color: rgb(68, 68, 68); font-family: AcuminPro, arial, helvetica, sans-serif; font-size: 15px; margin-left: 25px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">4. “Aku rela di penjara asalkan bersama buku, karena dengan buku aku bebas.” – Mohammad Hatta</span></p><p style=\"text-align: justify; overflow-wrap: break-word; color: rgb(68, 68, 68); font-family: AcuminPro, arial, helvetica, sans-serif; font-size: 15px; margin-left: 25px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">5. “Siapapun yang terhibur dengan buku-buku, kebahagiaan tak akan sirna dari dirinya.” – Ali bin Abi Thalib</span></p><p style=\"text-align: justify; overflow-wrap: break-word; color: rgb(68, 68, 68); font-family: AcuminPro, arial, helvetica, sans-serif; font-size: 15px; margin-left: 25px;\"><span style=\"font-weight: bolder; font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">Selamat hari buku sedunia ya...</span></p><div style=\"text-align: justify;\"><br></div><p style=\"margin: 0.5em 0px; color: rgb(32, 33, 34); font-family: sans-serif; font-size: 14px;\"><sup id=\"cite_ref-6\" class=\"reference\" style=\"font-size: 11.2px; line-height: 1; unicode-bidi: isolate; white-space: nowrap;\"></sup></p>', '2022-11-15 12:46:24'),
(13, 'Informasi E-Journal', '', '<p><img src=\"../gambar/149e9677a5989fd342ae44213df68868.png\" style=\"width: 25%;\">&nbsp;</p><p style=\"color: rgb(2, 2, 2); font-family: Verdana; font-size: 11px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";=\"\" font-size:=\"\" 14px;\"=\"\">U<span style=\"font-size: 14px;\">ntuk akses Emerald silahkan klik link berikut:</span></span><br><a href=\"https://www.emerald.com/insight/\" target=\"_blank\"><b>https://www.emerald.com/insight</b></a></p><p style=\"color: rgb(2, 2, 2); font-family: Verdana; font-size: 11px;\"><span style=\"font-family: \" comic=\"\" sans=\"\" ms\";\"=\"\">Untuk petunjuk penggunaan Emerald silahkan klik link berikut:</span><br><a href=\"http://library.ubm.ac.id/emerald2.pdf\" target=\"_blank\"><b>Petunjuk Penggunaan Emerald</b></a></p>', '2022-11-15 12:36:49'),
(14, 'Informasi E-Journal', '', '<p><img src=\"../gambar/f899139df5e1059396431415e770c6dd.png\" style=\"width: 25%;\"><span style=\"color: rgb(2, 2, 2); font-family: \" comic=\"\" sans=\"\" ms\";=\"\" font-size:=\"\" 11px;\"=\"\"><br></span></p><p><span style=\"color: rgb(2, 2, 2); font-family: \" comic=\"\" sans=\"\" ms\";=\"\" font-size:=\"\" 11px;\"=\"\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\">Perpustakaan Nasional URL : </span><a href=\"http://e-resources.perpusnas.go.id/\" target=\"_blank\">http://e-resources.perpusnas.go.id/</a></span><br style=\"color: rgb(2, 2, 2); font-family: Verdana; font-size: 11px;\"><br style=\"color: rgb(2, 2, 2); font-family: Verdana; font-size: 11px;\"></p><div style=\"text-align: justify;\"><span style=\"color: rgb(2, 2, 2); font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";=\"\" font-size:=\"\" 11px;\"=\"\">Untuk memenuhi kebutuhan pemustaka, Perpustakaan Nasional RI melanggan berbagai bahan</span></div><span style=\"color: rgb(2, 2, 2); font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";=\"\" font-size:=\"\" 11px;\"=\"\"><div style=\"text-align: justify;\">perpustakaan digital online (e-Resources) seperti jurnal, ebookm karys referensi online lainnya. Untuk</div></span><span style=\"color: rgb(2, 2, 2); font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";=\"\" font-size:=\"\" 11px;\"=\"\"><div style=\"text-align: justify;\">jurnal antara lain: Cambridge University Press, Cengage Learning, Ebsco Host.</div></span><p></p>', '2022-11-17 13:23:23'),
(15, 'Informasi E-Journal', '', '<p><img src=\"../gambar/42a0e188f5033bc65bf8d78622277c4e.png\" style=\"font-family: var(--bs-font-sans-serif); font-size: 1rem; width: 269px;\"></p><p><span style=\"color: rgb(2, 2, 2); font-family: &quot;Comic Sans MS&quot;; font-size: 11px;\">Untuk akses Google Scholar silahkan klik link berikut:</span></p><p><a href=\"https://scholar.google.com/\" target=\"_blank\">https://scholar.google.com/</a><br></p>', '2022-11-17 13:28:58');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `judul`, `isi`, `tgl_isi`) VALUES
(1, 'Perpustakaan XYZ', '<div style=\"line-height: 19px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\">Perpustakaan XYZ didirikan sejak tahun 2022 hingga sekarang oleh web developper Edo Juliyanto.</span></div>', '2022-11-15 12:11:14'),
(2, 'About', '<div style=\"text-align: left; line-height: 19px;\"><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">Situs web perpustakaan XYZ adalah salah satu layanan yang diperoleh pengguna dalam memanfaatkan dan mengeksplorasi koleksi yang dimiliki oleh sebuah perpustakaan dengan menggunakan jaringan internet. Situs web perpustakaan biasanya bertujuan untuk mempermudah pengguna untuk mencari koleksi yang dimiliki oleh sebuah perpustakaan tanpa harus melakukan kunjungan secara fisik ke perpustakaan tersebut.</span></div>', '2022-11-15 12:07:50'),
(3, 'Contact', '<p style=\"margin: 10px 0px; padding: 10px 0px;\"><font face=\"Comic Sans MS\">Jalan Pelepah Indah I Blok LB2, No.4, Kelapa Gading, RT.5/RW.18, Klp. Gading Tim., Kec. Klp. Gading, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240</font></p><p style=\"margin: 10px 0px; padding: 10px 0px;\"><font face=\"Comic Sans MS\">Call : (021) 888 526 1</font></p>', '2022-11-15 12:26:40'),
(4, 'Social', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\"><b>FOLLOW US</b></span></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">Instagram : perpustakaan_xyz</span></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">Email&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: perpustakaanxyz@gmail.com</span></p><p><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">﻿</span><span style=\"font-family: \" comic=\"\" sans=\"\" ms\";\"=\"\"><br></span><br></p>', '2022-11-15 11:25:29');

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE `search` (
  `id` int(11) NOT NULL,
  `foto` text NOT NULL,
  `judul` text NOT NULL,
  `penerbit` text NOT NULL,
  `tahun_terbit` text NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `pengarang` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `search`
--

INSERT INTO `search` (`id`, `foto`, `judul`, `penerbit`, `tahun_terbit`, `lokasi`, `jumlah`, `pengarang`, `tgl_isi`) VALUES
(6, 'search_1668424824_book1.jpg', '<p>The Python Book</p>', 'John', '2019', 'Ancol', '1', 'Andrew', '2022-11-14 11:23:30'),
(7, 'search_1668693098_book 3.jpg', '<p><span style=\"color: rgb(32, 33, 36); font-family: &quot;Comic Sans MS&quot;; font-size: 18px;\">Digital Marketing pada Start Up dan UMKM: Praktik Melakukan Pemasaran Berbasis Digital Menuju UMKM Tangguh, Kompetitif dan Unggul di Era Revolusi Industri 4.0</span><span style=\"font-size: 18px;\">﻿</span><br></p>', 'Absolute Media', '2021', 'Ancol', '1', 'Ina Ratnasari, S.E., M.M, dkk', '2022-11-17 13:51:38');

-- --------------------------------------------------------

--
-- Table structure for table `search_jurnal`
--

CREATE TABLE `search_jurnal` (
  `id` int(11) NOT NULL,
  `foto` text NOT NULL,
  `judul` text NOT NULL,
  `penerbit` text NOT NULL,
  `tahun_terbit` text NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `pengarang` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `search_jurnal`
--

INSERT INTO `search_jurnal` (`id`, `foto`, `judul`, `penerbit`, `tahun_terbit`, `lokasi`, `jumlah`, `pengarang`, `tgl_isi`) VALUES
(2, 'search_1668695838_jurnal 1.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">PERAN PUSTAKAWAN AI (ARTIFICIAL INTELLIGENT) SEBAGAI\r\nSTRATEGI PROMOSI PERPUSTAKAAN PERGURUAN TINGGI DI\r\nERA REVOLUSI 4.0&nbsp;</span><br></p>', 'BIBLIOTIKA : Jurnal Kajian Perpustakaan dan Informasi', '2019', 'Serpong', '1', 'Evi Aprilia Sari', '2022-11-17 14:37:18'),
(3, 'search_1668696275_jurnal-2.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">IMPLEMENTASI AUGMENTED REALITY UNTUK\r\nPEMBELAJARAN INTERAKTIF</span><br></p>', 'ILKOM Jurnal Ilmiah', '2017', 'Ancol', '1', 'Dedy Atmajaya', '2022-11-17 14:44:35');

-- --------------------------------------------------------

--
-- Table structure for table `search_skripsi`
--

CREATE TABLE `search_skripsi` (
  `id` int(11) NOT NULL,
  `foto` text NOT NULL,
  `judul` text NOT NULL,
  `penerbit` text NOT NULL,
  `tahun_terbit` text NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `pengarang` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `search_skripsi`
--

INSERT INTO `search_skripsi` (`id`, `foto`, `judul`, `penerbit`, `tahun_terbit`, `lokasi`, `jumlah`, `pengarang`, `tgl_isi`) VALUES
(1, 'search_1668696672_skripsi_1.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\">SISTEM BERBASIS PENGETAHUAN UNTUK\r\nMENGIDENTIFIKASI JENIS BURUNG KENARI LOKAL\r\nMENGGUNAKAN METODE CERTAINTY FACTOR</span><br></p>', 'SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER ', '2018', 'Serpong', '1', 'ARDI RADITYO', '2022-11-17 14:51:12'),
(2, 'search_1668696754_skripsi_2.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">PEMROGRAMAN APLIKASI MOBILE BERBASIS ANDROID\r\nOIA UGM: PANDUAN STUDI DI UGM BAGI MAHASISWA ASING</span><br></p>', 'SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER ', '2018', 'Serpong', '1', 'JEMY PARTIANTO', '2022-11-17 14:52:34');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `nama`, `foto`, `isi`, `tgl_isi`) VALUES
(1, 'Ruang Tax Center', 'services_1668504832_service_4.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">﻿Merupakan tempat dimana terdapat koleksi-koleksi buku perpajakan.</span><br></p>', '2022-11-15 09:33:52'),
(4, 'Ruang Petugas Perpustakaan', 'services_1668504307_service_3.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">﻿Merupakan tempat pengunjung dapat mendapatkan informasi yang dibutuhkan atau memerlukan bantuan.</span><br></p>', '2022-11-15 09:25:07'),
(5, 'Ruang Diskusi', 'services_1668504076_service_2.jpg', '<p><span style=\"color: rgb(2, 2, 2); font-family: &quot;Comic Sans MS&quot;; font-size: 18px;\">Merupakan tempat dimana para anggota yang sudah mendaftar dapat menggunakan fasilitas untuk diskusi atau belajar bersama.</span><span style=\"font-family: &quot;Comic Sans MS&quot;; font-size: 18px;\">﻿</span><br></p>', '2022-11-15 09:21:16'),
(6, 'Ruang Baca', 'services_1668503639_service_1.jpg', '<span style=\"color: rgb(2, 2, 2); font-family: &quot;Comic Sans MS&quot;;\" comic=\"\" sans=\"\" ms\";\"=\"\" ms\";=\"\" font-size:=\"\" 12px;\"=\"\">Merupakan tempat untuk membaca buku-buku yang dipinjam bagi para anggota perpustakaan.</span>', '2022-11-15 09:15:14'),
(7, 'Library Cafe', 'services_1668504983_service_5.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">﻿Merupakan tempat dimana anggota dapat membeli makanan dan minuman sambil membaca buku atau berdiskusi bersama teman.</span><br></p>', '2022-11-15 09:36:23'),
(8, 'Ruang Loker', 'services_1668505200_service_6.jpg', '<p><span style=\"font-family: &quot;Comic Sans MS&quot;;\">﻿Merupakan tempat penitipan barang seperti tas, alat elektronik dan lain-lain.</span><br></p>', '2022-11-15 09:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `status_pemesanan`
--

CREATE TABLE `status_pemesanan` (
  `id` int(11) NOT NULL,
  `nib` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_pesan` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tanggal_tersedia` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lokasi_ambil` varchar(255) NOT NULL,
  `status_tersedia` varchar(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status_pemesanan`
--

INSERT INTO `status_pemesanan` (`id`, `nib`, `judul`, `tanggal_pesan`, `tanggal_tersedia`, `lokasi_ambil`, `status_tersedia`, `keterangan`) VALUES
(1, '32190001', 'Pemrograman SQL', '2022-11-04 06:14:11', '2022-11-11 06:14:11', 'ancol', 'tersedia', 'proses pemesanan');

-- --------------------------------------------------------

--
-- Table structure for table `status_peminjaman`
--

CREATE TABLE `status_peminjaman` (
  `id` int(11) NOT NULL,
  `nib` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_pinjam` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tanggal_kembali` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `denda` varchar(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status_peminjaman`
--

INSERT INTO `status_peminjaman` (`id`, `nib`, `judul`, `tanggal_pinjam`, `tanggal_kembali`, `denda`, `keterangan`) VALUES
(1, '32190008', 'Pemrograman PHP', '2022-11-17 13:11:00', '2022-11-24 13:11:00', '0', '<p>Dalam periode peminjaman</p>');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `status` text NOT NULL,
  `token_ganti_password` text DEFAULT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `status`, `token_ganti_password`, `tgl_isi`) VALUES
(1, 'Edo Juliyanto', 'edojuliyanto2001@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9cfdf10e8fc047a44b08ed031e1f0ed1', '2a9d121cd9c3a1832bb6d2cc6bd7a8a7', '2022-11-10 10:05:34'),
(2, 'Edo Juliyanto', 'edojuliyanto01@gmail.com', 'c33367701511b4f6020ec61ded352059', 'be83ab3ecd0db773eb2dc1b0a17836a1', '', '2022-11-07 14:32:10'),
(6, 'Edo', 'edojuliyanto05@gmail.com', 'c33367701511b4f6020ec61ded352059', '1', '', '2022-11-12 09:38:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `halaman`
--
ALTER TABLE `halaman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search`
--
ALTER TABLE `search`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search_jurnal`
--
ALTER TABLE `search_jurnal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search_skripsi`
--
ALTER TABLE `search_skripsi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_pemesanan`
--
ALTER TABLE `status_pemesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_peminjaman`
--
ALTER TABLE `status_peminjaman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `halaman`
--
ALTER TABLE `halaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `search`
--
ALTER TABLE `search`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `search_jurnal`
--
ALTER TABLE `search_jurnal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `search_skripsi`
--
ALTER TABLE `search_skripsi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `status_pemesanan`
--
ALTER TABLE `status_pemesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `status_peminjaman`
--
ALTER TABLE `status_peminjaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
