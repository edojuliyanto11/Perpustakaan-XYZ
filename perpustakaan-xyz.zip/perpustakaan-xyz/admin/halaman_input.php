<?php include("inc_header.php")?>
<?php
$judul   = "";
$kutipan = "";
$isi     = "";
$eror    = "";
$sukses  = "";

if(isset ($_GET['id'])){
    $id = $_GET['id'];
}else{
    $id = "";
}

if($id != ""){
    $sql1    = "select * from halaman where id = '$id'";
    $q1      = mysqli_query($koneksi,$sql1);
    $r1      = mysqli_fetch_array($q1);
    $judul   = $r1['judul'];
    $kutipan = $r1['kutipan'];
    $isi     = $r1['isi'];

    if($isi == ''){
        $eror = "Data tidak ditemukan";
    }
}

if(isset($_POST['simpan'])){
    $judul   = $_POST['judul'];
    $isi     = $_POST['isi'];
    $kutipan = $_POST['kutipan'];

    if($judul == '' or $isi == ''){
        $eror = "Silahkan masukkan semua data yakni adalah data isi dan judul.";
    }

    if(empty($eror)){
        if($id != ""){
            $sql1  = "update halaman set judul= '$judul', kutipan= '$kutipan', isi= '$isi', tgl_isi= now() where id = '$id'";
        }else {
            $sql1    = "insert into halaman(judul,kutipan,isi) values ('$judul', '$kutipan', '$isi')";
        }
        $q1      = mysqli_query($koneksi,$sql1);
        if($q1){
            $sukses  = "Sukses memasukan data";
        }else{
            $eror   = "Gagal memasukan data";
        }
    }
}


?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h1>Halaman Admin Input Data</h1>
<p>
    <a href="halaman.php">
        <input type="button" class="btn btn-primary"  value="Kembali Halaman Admin"/>
    </a>
</p>
<?php
    if ($eror){
?>
    <div class="alert alert-danger" role="alert">
        <?php echo $eror ?>
    </div>
<?php
}
?>
<?php
if ($sukses){
?>
    <div class="alert alert-primary" role="alert">
        <?php echo $sukses ?>
    </div>
<?php
}
?>

<form action="" method="post">
    <div class="mb-3 row">
        <label for="judul" class="col-sm-2 col-form-label">Judul</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="judul" placeholder="<?php echo $judul?>" name="judul">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="kutipan" class="col-sm-2 col-form-label">Kutipan</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="kutipan" placeholder="<?php echo $kutipan?>" name="kutipan">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="isi" class="col-sm-2 col-form-label">Isi</label>
        <div class="col-sm-10">
            <textarea name="isi" class="form-control" id="summernote"><?php echo $isi ?></textarea>   
        </div> 
    </div>
    <div class="mb-3 row">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary"/>    
        </div>
    </div>
</form>
<?php include("inc_footer.php")?>