<?php
session_start();
if(isset($_SESSION['admin_username'])!=''){
    header("location:index.php");
    exit();
}
include("../inc/inc_koneksi.php");

$username  = "";
$password  = "";
$err       = "";

if(isset($_POST['Login'])){
    $username   = $_POST['username'];
    $password   = $_POST['password'];

        if($username == '' or $password == ''){
            $err = "Silahkan masukkan semua isian";
        }else{
            $sql1 = "select * from admin where username = '$username'";
            $q1   = mysqli_query($koneksi,$sql1);
            $r1   = mysqli_fetch_array($q1);
            $n1   = mysqli_num_rows($q1);

            if($n1 < 1){
                $err = "Username tidak ditemukan";
            }elseif($r1['password'] != md5($password)){
                $err = "Password yang kamu masukkan tidak sesuai";
            }else{
                $_SESSION['admin_username'] = $username;
                header("location:index.php");
                exit();
            }
        }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
                background-image: url(https://img.freepik.com/premium-photo/blurred-bookshelf-library-room_1484-1953.jpg?size=626&ext=jpg&ga=GA1.2.1853630230.1666961951&semt=sph);
                background-repeat: no-repeat;
                background-size: 100%;
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Login Admin</title>
</head>
<body style="width:100%;max-width:330px;margin:auto;padding:15px">
<form action="" method="POST">
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
    <h1 style="margin-left: 30px;">Login Admin</h1>
    <?php
    if($err){
    ?>
    <div class="alert alert-danger" role="alert">
        <?php echo $err?>
    </div>
    <?php
    }
    ?>
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username anda.." value="<?php echo $username?>"/>
    </div>
    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password"/>
    </div><br>
    <a href="../index.php" class="btn btn-primary">User Page</a>
    <button style="margin-left: 0px;" type="submit" class="btn btn-primary" name="Login">Login</button>
</form>   
</body>
</html>