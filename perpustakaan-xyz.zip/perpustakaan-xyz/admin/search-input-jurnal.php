<?php include("inc_header.php")?>
<?php
$foto         = "";
$judul        = "";
$penerbit     = "";
$tahun_terbit = "";
$lokasi       = "";
$jumlah       = "";
$pengarang    = "";
$foto_name    = "";
$eror         = "";
$sukses       = "";

if(isset ($_GET['id'])){
    $id = $_GET['id'];
}else{
    $id = "";
}

if($id != ""){
    $sql1         = "select * from search_jurnal where id = '$id'";
    $q1           = mysqli_query($koneksi,$sql1);
    $r1           = mysqli_fetch_array($q1);
    $foto         = $r1['foto'];
    $judul        = $r1['judul'];
    $penerbit     = $r1['penerbit'];
    $tahun_terbit = $r1['tahun_terbit'];
    $lokasi       = $r1['lokasi'];
    $jumlah       = $r1['jumlah'];
    $pengarang    = $r1['pengarang'];

    if($judul == ''){
        $eror = "Data tidak ditemukan";
    }
}

if(isset($_POST['simpan'])){
    $judul        = $_POST['judul'];
    $penerbit     = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $lokasi       = $_POST['lokasi'];
    $jumlah       = $_POST['jumlah'];
    $pengarang    = $_POST['pengarang'];

    if($judul == '' or $penerbit == '' or $tahun_terbit == '' or $lokasi == '' or $jumlah == '' or $pengarang == ''){
        $eror = "Silahkan masukkan semua data yakni adalah data judul, penerbit, tahun terbit, lokasi, jumlah dan pengarang.";
    }
    //Array ( [foto] => Array ( [name] => rak.svg [type] => image/svg+xml [tmp_name] => C:\xampp\tmp\phpD46A.tmp [error] => 0 [size] => 80942 ) )
    //print_r($_FILES);
    if($_FILES['foto']['name']){
        $foto_name = $_FILES['foto']['name'];
        $foto_file = $_FILES['foto']['tmp_name'];

        $detail_file = pathinfo($foto_name);
        $foto_extension =$detail_file['extension'];
        //print_r($detail_file);
        //Array ( [dirname] => . [basename] => rak.svg [extension] => svg [filename] => rak )
        $extension_allow = array("jpg","jpeg","png","SVG","gif");
        if(!in_array($foto_extension,$extension_allow)){
            $eror = "Extension yang diperbolehkan hanya jpg, jpeg, png, svg, dan gif";
        }
    }

    if(empty($eror)){
        if($foto_name){
            $directory = "../gambar";
            @unlink($directory."/$foto");//delete data
            $foto_name = "search_".time()."_".$foto_name;
            move_uploaded_file($foto_file,$directory."/".$foto_name);

            $foto = $foto_name;
        }else{
            $foto_name = $foto; //memasukkan data dari data yang sebelumnya ada
        }

        if($id != ""){
            $sql1  = "update search_jurnal set foto= '$foto_name', judul= '$judul', penerbit= '$penerbit', tahun_terbit= '$tahun_terbit', lokasi= '$lokasi', jumlah= '$jumlah', pengarang= '$pengarang', tgl_isi= now() where id = '$id'";
        }else {
            $sql1    = "insert into search_jurnal(foto,judul,penerbit,tahun_terbit,lokasi,jumlah,pengarang) values ('$foto_name', '$judul', '$penerbit', '$tahun_terbit', '$lokasi', '$jumlah', '$pengarang')";
        }
        $q1      = mysqli_query($koneksi,$sql1);
        if($q1){
            $sukses  = "Sukses memasukan data";
        }else{
            $eror   = "Gagal memasukan data";
        }
    }
}


?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h1>Halaman Admin Input Data Jurnal</h1>
<p>
    <a href="search-jurnal-admin.php">
        <input type="button" class="btn btn-primary"  value="Kembali Halaman Admin Search"/>
    </a>
</p>
<?php
    if ($eror){
?>
    <div class="alert alert-danger" role="alert">
        <?php echo $eror ?>
    </div>
<?php
}
?>
<?php
if ($sukses){
?>
    <div class="alert alert-primary" role="alert">
        <?php echo $sukses ?>
    </div>
<?php
}
?>

<form action="" method="post" enctype="multipart/form-data">
    <div class="mb-3 row">
        <label for="foto" class="col-sm-2 col-form-label">Foto</label>
        <div class="col-sm-10">
            <?php
            if($foto){
                echo "<img src='../gambar/$foto' style='max-height:100px;max-width:100px;'/>";
            }
            ?>
            <input type="file" class="form-control" id="foto" name="foto">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="judul" class="col-sm-2 col-form-label">Judul</label>
        <div class="col-sm-10">
        <textarea name="judul" class="form-control" id="summernote"><?php echo $judul ?></textarea>
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="penerbit" class="col-sm-2 col-form-label">Penerbit</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="penerbit" placeholder="<?php echo $penerbit?>" name="penerbit">
        </div> 
    </div>
    <div class="mb-3 row">
        <label for="tahun_terbit" class="col-sm-2 col-form-label">Tahun Terbit</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="tahun_terbit" placeholder="<?php echo $tahun_terbit?>" name="tahun_terbit">
        </div> 
    </div>
    <div class="mb-3 row">
        <label for="lokasi" class="col-sm-2 col-form-label">Lokasi</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="lokasi" placeholder="<?php echo $lokasi?>" name="lokasi">
        </div> 
    </div>
    <div class="mb-3 row">
        <label for="jumlah" class="col-sm-2 col-form-label">Jumlah</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="jumlah" placeholder="<?php echo $jumlah?>" name="jumlah">
        </div> 
    </div>
    <div class="mb-3 row">
        <label for="pengarang" class="col-sm-2 col-form-label">Pengarang</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="pengarang" placeholder="<?php echo $pengarang?>" name="pengarang">
        </div> 
    </div>
    <div class="mb-3 row">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary"/>    
        </div>
    </div>
</form>
<?php include("inc_footer.php")?>