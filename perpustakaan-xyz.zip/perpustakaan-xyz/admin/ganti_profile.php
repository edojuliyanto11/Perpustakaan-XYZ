<?php include("inc_header.php")?>
<?php
$err        = "";
$sukses     = "";
if(isset($_POST['simpan'])){

    $password_lama          = $_POST['password_lama'];
    $password               = $_POST['password'];
    $konfirmasi_password    = $_POST['konfirmasi_password'];

    $sql1 = "select * from admin where username = '" .$_SESSION['admin_username']."'";
    $q1 = mysqli_query($koneksi,$sql1);
    $r1 = mysqli_fetch_array($q1);
    if(md5($password_lama) != $r1['password']){
        $err .= "<li>Password yang kamu tuliskan tidak sesuai dengan password sebelumnya</li>";
    }

    if($password_lama == '' or $konfirmasi_password == '' or $password == ''){
        $err .= "<li>Silahkan masukkan password lama, password baru serta konfirmasi password</li>";
    }

    if($password != $konfirmasi_password){
        $err .= "<li>Silahkan masukkan password dan konfirmasi password yang sama</li>";
    }

    if(strlen($password) < 6){
        $err .= "<li>Panjang karakter yang diizinkan untuk password adalah 6 karakter, minimal.</li>";
    }

    if(empty($err)){
        $sql1 = "update admin set password = md5($password) where username ='".$_SESSION['admin_username']."'";
        mysqli_query($koneksi,$sql1);
        $sukses = "Berhasil mengganti Password";
    }
}
?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h1>Ganti Password Akun</h1>
<?php
if($sukses){
    ?>
    <div class="alert alert-primary">
        <ul><?php echo $sukses?></ul>
    </div>
    <?php
}
?>
<?php
if($err){
    ?>
    <div class="alert alert-danger">
        <ul><?php echo $err?></ul>
    </div>
    <?php
}
?>
<form action="" method="POST">
    <div class="mb-3 row">
        <label for="password_lama" class="col-sm-3 col-form-label">Password Lama</label>
        <div class="col-sm-9">
            <input type="password" class="form-control" id="password_lama" name="password_lama"/>
        </div>
    </div>
    <div class="mb-3 row">
        <label for="password" class="col-sm-3 col-form-label">Password Baru</label>
        <div class="col-sm-9">
            <input type="password" class="form-control" id="password" name="password"/>
        </div>
    </div>
    <div class="mb-3 row">
        <label for="konfirmasi_password" class="col-sm-3 col-form-label">Konfirmasi Password</label>
        <div class="col-sm-9">
            <input type="password" class="form-control" id="konfirmasi_password" name="konfirmasi_password"/>
        </div>
    </div>
    <div class="mb-3 row">
        <div class="col-sm-3"></div>
        <div class="col-sm-9">
            <input type="submit" class="btn btn-primary" name="simpan" value="Ganti Password Baru"/>
        </div>
    </div>
</form>

<?php include("inc_footer.php")?>