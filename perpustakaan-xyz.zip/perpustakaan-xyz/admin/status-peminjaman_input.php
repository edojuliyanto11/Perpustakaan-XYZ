<?php include("inc_header.php")?>
<?php
$nib                = "";
$judul              = "";
$tanggal_pinjam     = "";
$tanggal_kembali    = "";
$denda              = "";
$keterangan         = "";
$eror               = "";
$sukses             = "";

if(isset ($_GET['id'])){
    $id = $_GET['id'];
}else{
    $id = "";
}

if($id != ""){
    $sql1               = "select * from status_peminjaman where id = '$id'";
    $q1                 = mysqli_query($koneksi,$sql1);
    $r1                 = mysqli_fetch_array($q1);
    $nib                = $r1['nib'];
    $judul              = $r1['judul'];
    $tanggal_pinjam     = $r1['tanggal_pinjam'];
    $tanggal_kembali    = $r1['tanggal_kembali'];
    $denda              = $r1['denda'];
    $keterangan         = $r1['keterangan'];

    if($keterangan == ''){
        $eror = "Data tidak ditemukan";
    }
}

if(isset($_POST['simpan'])){
    $nib                = $_POST['nib'];
    $judul              = $_POST['judul'];
    $tanggal_pinjam     = $_POST['tanggal_pinjam'];
    $tanggal_kembali    = $_POST['tanggal_kembali'];
    $denda              = $_POST['denda'];
    $keterangan         = $_POST['keterangan'];


    if($judul == '' or $keterangan == ''){
        $eror = "Silahkan masukkan semua data yakni adalah data judul dan keterangan.";
    }

    if(empty($eror)){
        if($id != ""){
            $sql1  = "update status_peminjaman set nib= '$nib', judul= '$judul', tanggal_pinjam= '$tanggal_pinjam', tanggal_kembali= '$tanggal_kembali', denda= '$denda', keterangan= '$keterangan'  where id = '$id'";
        }else {
            $sql1  = "insert into status_peminjaman(nib,judul,tanggal_pinjam,tanggal_kembali,denda,keterangan) values ('$nib','$judul', '$tanggal_pinjam', '$tanggal_kembali', '$denda', '$keterangan')";
        }
        $q1      = mysqli_query($koneksi,$sql1);
        if($q1){
            $sukses  = "Sukses memasukan data";
        }else{
            $eror   = "Gagal memasukan data";
        }
    }
}


?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h1>Halaman Admin Input Data Status Peminjaman</h1>
<p>
    <a href="status-peminjaman.php">
        <input type="button" class="btn btn-primary"  value="Kembali Halaman Admin Status Peminjaman"/>
    </a>
</p>
<?php
    if ($eror){
?>
    <div class="alert alert-danger" role="alert">
        <?php echo $eror ?>
    </div>
<?php
}
?>
<?php
if ($sukses){
?>
    <div class="alert alert-primary" role="alert">
        <?php echo $sukses ?>
    </div>
<?php
}
?>

<form action="" method="post">
    <div class="mb-3 row">
        <label for="nib" class="col-sm-2 col-form-label">NIB</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="nib" placeholder="<?php echo $nib?>" name="nib">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="judul" class="col-sm-2 col-form-label">Judul</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="judul" placeholder="<?php echo $judul?>" name="judul">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="tanggal_pinjam" class="col-sm-2 col-form-label">Tanggal Pinjam</label>
        <div class="col-sm-10">
            <input type="datetime-local" class="form-control" id="tanggal_pinjam" placeholder="<?php echo $tanggal_pinjam?>" name="tanggal_pinjam">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="tanggal_kembali" class="col-sm-2 col-form-label">Tanggal Kembali</label>
        <div class="col-sm-10">
            <input type="datetime-local" class="form-control" id="tanggal_kembali" placeholder="<?php echo $tanggal_kembali?>" name="tanggal_kembali">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="denda" class="col-sm-2 col-form-label">Denda</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="denda" placeholder="<?php echo $denda?>" name="denda">
        </div>  
    </div>
    <div class="mb-3 row">
        <label for="keterangan" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea name="keterangan" class="form-control" id="summernote"><?php echo $keterangan ?></textarea>   
        </div> 
    </div>
    <div class="mb-3 row">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary"/>    
        </div>
    </div>
</form>
<?php include("inc_footer.php")?>