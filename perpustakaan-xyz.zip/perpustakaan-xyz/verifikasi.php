<?php include("inc_header.php")?>
<?php
$err    = "";
$sukses = "";

if(!isset($_GET['email']) or !isset($_GET['kode'])){
    $err = "Data yang diperlukan untuk verifikasi tidak tersedia.";
}else{
    $email = $_GET['email'];
    $kode  = $_GET['kode'];

    $sql1 = "select * from users where email = '$email'";
    $q1   = mysqli_query($koneksi,$sql1);
    $r1   = mysqli_fetch_array($q1);
    if($r1['status'] == $kode){
        $sql2 = "update users set status = '1' where email = '$email'";
        mysqli_query($koneksi,$sql2);
        $sukses = "Akun telah aktif. Silahkan login dihalaman login.";
    }else{
        $err = "Kode tidak valid";
    }
}
?>
<head>
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<h3>Halaman Verifikasi</h3>
<?php if($err) { echo "<div class='error'>$err</div>";}?>
<?php if($sukses) { echo "<div class='sukses'>$sukses</div>";}?>
<?php include("inc_footer.php")?>