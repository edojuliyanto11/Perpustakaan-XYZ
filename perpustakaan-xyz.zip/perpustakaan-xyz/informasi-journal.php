<?php include_once("inc_header_personal.php")?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal</title>
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<body>
       <!-- untuk informasi e-journal -->
       <section id="journal">
            <div class="kolom">
                <p class="deskripsi"><?php echo ambil_kutipan('13')?></p>
                <h2><?php echo ambil_judul('13')?></h2>
                <p><?php echo maximum_kata(ambil_isi('13'),20)?></p>
                <p><a href="<?php echo buat_link_halaman('13')?>" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
            </div>
            <img src="<?php echo ambil_gambar('13')?>" style="margin-top:20px; width: 500px; height: 300px;""/>
        </section>
        <section id="journal">
            <div class="kolom">
                <p class="deskripsi"><?php echo ambil_kutipan('14')?></p>
                <h2><?php echo ambil_judul('14')?></h2>
                <p><?php echo maximum_kata(ambil_isi('14'),20)?></p>
                <p><a href="<?php echo buat_link_halaman('14')?>" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
            </div>
            <img src="<?php echo ambil_gambar('14')?>" style="margin-top:20px; width: 300px; height: 300px;"/>
        </section>
        <section id="journal">
            <div class="kolom">
                <p class="deskripsi"><?php echo ambil_kutipan('15')?></p>
                <h2><?php echo ambil_judul('15')?></h2>
                <p><?php echo maximum_kata(ambil_isi('15'),20)?></p>
                <p><a href="<?php echo buat_link_halaman('15')?>" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
            </div>
            <img src="<?php echo ambil_gambar('15')?>" style="margin-top:20px; width: 350px; height: 350px;"/>
        </section>
</body>
</html>
<?php include_once("inc_footer.php")?>
