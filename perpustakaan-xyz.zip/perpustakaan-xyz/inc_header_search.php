<?php
    session_start();
    if($_SESSION['users_nama'] == ''){
        header("location:login.php");
        exit();
    }
    include("inc/inc_koneksi.php");
    include("inc/inc_fungsi.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Perpustakaan XYZ</title>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>  
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <link href="css/summernote-image-list.min.css">
    <script src="js/summernote-image-list.min.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+"/>
    <link rel="stylesheet" href="<?php echo url_dasar()?>/css/style.css">
    <!-- Hotjar Tracking Code for https://perpusxyz.000webhostapp.com/ -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:3191278,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
            })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script>
</head>
<body class="container">
    <header>
        <nav class="navbar navbar-expand-lg" style="background-color: #DEF5E5;">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a style="color: #000000" class="nav-link active" aria-current="page" href="search-buku.php">Halaman Pencarian Buku</a>
                        </li>
                        <li class="nav-item">
                            <a style="color: #000000" class="nav-link active" aria-current="page" href="search-jurnal.php">Halaman Pencarian Jurnal</a>
                        </li>
                        <li class="nav-item">
                            <a style="color: #000000" class="nav-link active" aria-current="page" href="search-skripsi.php">Halaman Pencarian Skripsi</a>
                        </li>
                        <li style="margin-top: 8px;" class="nav-item">
                            <?php if(isset($_SESSION['users_nama'])){
                                echo "<a href='".url_dasar()."/ganti_profile.php'>".$_SESSION['users_nama']."</a> | <a href='".url_dasar()."../logout.php'>Logout</a>";
                            }else{?>
                                <a class="nav-link active" aria-current="page" href="../daftar.php" class="tbl-biru">Sign Up</a>
                            <?php } ?>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header> 
    <main>
</body> 